CUDA_VISIBLE_DEVICES=1 python run_experiment.py emnist test --n_learners 3 --n_gmm 10 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_M1_10_M2_3_lr_0.1

CUDA_VISIBLE_DEVICES=0 python run_experiment.py emnist test --n_learners 6 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler constant \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64

CUDA_VISIBLE_DEVICES=2 python run_experiment.py emnist_r test --n_learners 2 --n_gmm 2 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist_shifted/FedGMM_M1_2_M2_2_lr_0.1


CUDA_VISIBLE_DEVICES=1 python run_experiment.py emnist_r FedEM --n_learners 2 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist_shifted/FedEM_new

Train Loss: 0.277 | Train Acc: 90.235% |Test Loss: 0.548 | Test Acc: 82.581% |
Train Reconstruction Loss: 91.049 | Train NLL: 44.022|Test Reconstruction Loss: 91.207 | Test NLL: 44.141 |
++++++++++++++++++++++++++++++++++++++++++++++++++
################################################################################
100%|#####################################################################| 200/200 [4:48:45<00:00, 89.64s/it][[0.3017144799232483], [0.3076132535934448], [0.3906722664833069]]
201it [4:50:06, 86.60s/it]


83.17



++++++++++++++++++++++++++++++
Global..
Train Loss: 0.356 | Train Acc: 87.038% |Test Loss: 0.520 | Test Acc: 82.636% |
++++++++++++++++++++++++++++++++++++++++++++++++++
################################################################################
100%|#################################################################################| 200/200 [1:37:47<00:00, 30.46s/it][8.42005395e-04 9.92303164e-01 6.85483032e-03]
201it [1:38:16, 29.33s/it]
(base) yuwu@dsss-gpu16:~/FedEM$ CUDA_VISIBLE_DEVICES=2 python run_experiment.py emnist FedEM --n_learners 3 --n_rounds 200 --bz 128 --lr 0.05  --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64







===========M=6==========
