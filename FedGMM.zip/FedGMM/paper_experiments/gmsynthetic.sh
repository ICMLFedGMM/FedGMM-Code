echo "Run FedGMM"
#python run_experiment.py gmsynthetic test --n_learners 3 --n_gmm 10  --n_rounds 200 --bz 128 --lr 0.05 \
#--lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
#--output_dimension 2 --logs_dir logs/artificial/FedGMM_M1_10

python run_experiment.py gmsynthetic test --n_learners 2 --n_gmm 2  --n_rounds 200 --bz 128 --lr 0.03 \
--lr_scheduler constant --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/FedGMM_M1_3_lr_0.03

echo "Run FedEM"
python run_experiment.py gmsynthetic FedEM --n_learners 2 --n_rounds 200 --bz 128 --lr 0.05 \
--lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/FedEM

# run FedAvg
echo "Run FedAvg"
python run_experiment.py gmsynthetic FedAvg --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/FedAvg

# run FedAvg + local adaption
echo "Run FedAvg + local adaption"
python run_experiment.py gmsynthetic FedAvg --n_learners 1 --locally_tune_clients --n_rounds 200 --bz 128 \
 --lr 0.01 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/FedAvg_adapt

# run training using local data only
echo "Run Local"
python run_experiment.py gmsynthetic local --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/local

# run Clustered FL
echo "Run Clustered FL"
python run_experiment.py gmsynthetic clustered --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/clustered

 # run FedProx
echo "Run FedProx"
python run_experiment.py gmsynthetic FedProx --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 --mu 0.1 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer prox_sgd --seed 1234 --verbose 1 --input_dimension 32 \
--output_dimension 2 --logs_dir logs/artificial/FedProx


#fedem 70.64%
#fedgmm 74.36%

#FedGMM 73.43%
#FedEM 67.41%

# For 300 clients
#FedGMM 7607
#FedEM 6944