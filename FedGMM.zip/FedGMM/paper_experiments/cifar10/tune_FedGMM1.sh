#
#echo "Run FedEM lr=0.04"
#python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.04 \
# --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
# --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.04 --embedding_dimension 64
#
#echo "Run FedEM lr=0.05"
#python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.05 \
# --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
# --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.05 --embedding_dimension 64
#
#echo "Run FedEM lr=0.07"
#python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.07 \
# --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
# --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.07 --embedding_dimension 64

echo "Run FedEM"
python run_experiment.py cifar10 FedEM --n_learners 2 --n_rounds 201 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234 --verbose 1

echo "Run FedEM lr=0.12"
python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.12 \
 --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
 --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.12 --embedding_dimension 64

echo "Run FedEM lr=0.15"
python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.15 \
 --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
 --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.15 --embedding_dimension 64

echo "Run FedEM lr=0.2"
python run_experiment.py cifar10 test --n_learners 2 --n_rounds 200 --bz 128 --lr 0.2 \
 --lr_scheduler multi_step --log_freq 10 --device cuda --optimizer sgd --seed 1234  \
 --verbose 1 --logs_dir logs/cifar10_validation/FedGMM_lr_0.2 --embedding_dimension 64