#cd ../../
CUDA_VISIBLE_DEVICES=3
# run FedAvg
echo "Run FedAvg"
python run_experiment.py emnist_r FedAvg --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1

# run FedAvg + local adaption
echo "Run FedAvg + local adaption"
python run_experiment.py emnist_r FedAvg --n_learners 1 --locally_tune_clients --n_rounds 200 --bz 128 \
 --lr 0.01 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1

# run training using local data only
echo "Run Local"
python run_experiment.py emnist_r local --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1

# run Clustered FL
echo "Run Clustered FL"
python run_experiment.py emnist_r clustered --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1

 # run FedProx
echo "Run FedProx"
python run_experiment.py emnist_r FedProx --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 --mu 0.1 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer prox_sgd --seed 1234 --verbose 1

# Run Richtarek's Formulation
echo "Run Personalized (Richtarek's Formulation)"
python run_experiment.py emnist_r personalized --n_learners 1 --n_rounds 200 --bz 128 --lr 0.01 --mu 1.0 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer prox_sgd --seed 1234 --verbose 1

echo "Run FedEM"
python run_experiment.py emnist FedEM --n_learners 3 --n_rounds 200 --bz 128 --lr 0.1 \
 --lr_scheduler multi_step --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64


echo "Run FedGMM"
python run_experiment.py emnist test --n_learners 3 --n_gmm 3 --n_rounds 200 --bz 128 --lr 0.1 \
 --lr_scheduler constant --log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 \
 --logs_dir logs/emnist/FedGMM_M1_3_M2_3_lr_0.1