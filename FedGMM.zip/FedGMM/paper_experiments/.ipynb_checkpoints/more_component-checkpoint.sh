echo "Run FedGMM lr=0.2 M=6"
CUDA_VISIBLE_DEVICES=2 python run_experiment.py emnist test --n_learners 10 --n_rounds 200 --bz 128 --lr 0.2  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_lr_0.2_M_10

echo "Run FedEM lr=0.1 M=6"
CUDA_VISIBLE_DEVICES=3 python run_experiment.py emnist FedEM --n_learners 6 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedEM_lr_0.1_M_6

CUDA_VISIBLE_DEVICES=0 python run_experiment.py emnist FedEM --n_learners 10 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \ 
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedEM_lr_0.1_M_10

CUDA_VISIBLE_DEVICES=1 python run_experiment.py emnist test --n_learners 10 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \ 
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_lr_0.1_M_10

CUDA_VISIBLE_DEVICES=2 python run_experiment.py emnist test --n_learners 10 --n_rounds 200 --bz 128 --lr 0.25  --lr_scheduler multi_step \ 
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_lr_0.25_M_10

CUDA_VISIBLE_DEVICES=3 python run_experiment.py emnist test --n_learners 10 --n_rounds 200 --bz 128 --lr 0.5  --lr_scheduler multi_step \ 
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_lr_0.5_M_10