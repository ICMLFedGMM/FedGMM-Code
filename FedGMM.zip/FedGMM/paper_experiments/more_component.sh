echo "Run FedGMM lr=0.2 M=6"
CUDA_VISIBLE_DEVICES=1 python run_experiment.py emnist test --n_learners 4 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedGMM_lr_0.1_M_4

CUDA_VISIBLE_DEVICES=3 python run_experiment.py emnist FedEM --n_learners 2 --n_rounds 200 --bz 128 --lr 0.1  --lr_scheduler multi_step \
--log_freq 5 --device cuda --optimizer sgd --seed 1234 --verbose 1 --embedding_dimension 64 --logs_dir logs/emnist/FedEM_lr_0.1_M_2

#MNIST: 97.68%
